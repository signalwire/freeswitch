#ifndef CONFIG_H
#define CONFIG_H

#define HAVE_STDLIB_H 1
#define snprintf _snprintf

#define strcasecmp stricmp
#define strncasecmp strnicmp

#endif 
