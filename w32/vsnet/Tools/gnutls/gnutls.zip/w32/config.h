#ifndef CONFIG_H
#define CONFIG_H

#define ENABLE_ANON
#define ENABLE_PKI

#define ssize_t int
#define pid_t int

#define SIZEOF_UNSIGNED_LONG 4
#define SIZEOF_UNSIGNED_INT 4
#define SIZEOF_UNSIGNED_SHORT 2
#define SIZEOF_UNSIGNED_CHAR 1

#define STDC_HEADERS
#define HAVE_MEMMOVE
#define HAVE_ISASCII
#define inline __inline
#include <errno.h>

#define HAVE_DECL_MEMMEM 0
#include <io.h>

#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))

#define GNUTLS_LIBTASN1_VERSION "0.2.13"
#define VERSION "1.2.4"
#undef WORDS_BIGENDIAN

#define vsnprintf _vsnprintf
#define snprintf _snprintf

#define strcasecmp stricmp
#define HAVE_LIBZ
#define USE_LZO
#define USE_MINILZO
#endif
